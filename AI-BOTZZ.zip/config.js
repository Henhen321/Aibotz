const fs = require('fs')
const chalk = require('chalk')
const axios = require('axios');

// INGAT CUY INI CUMA SC HASIL RENAME ATAU RECODE YA

// Credit : @theJayy_
// Ori : @callmevinz

//=== Edit Disini 🔥
global.namabot = "C-Arv X MD"
global.namaowner = "./Henz"
global.packname = "Sticker by"
global.creator = "C-Arv X MD"
global.author = "C-Arv-MD\n\nBot WhatsApp"
global.wm = "C-Arv-MD"
global.syt = "https://www.youtube.com/@czxkuba"
global.sgc = "https://chat.whatsapp.com/KMPr7fXHRYBABxYdHReQVB"
global.idgc = "@g.us"
global.email = "drazathenhen@gmail.com"
global.sig = "https://Instagram.com/@drajat.henhen"
global.myweb = "https://henc.rf.gd"
global.footer_text = "© C-Arv-MD"
global.owner = ['6285866034212']
global.gifin = "https://telegra.ph/file/0cf1c5039a2be1b66ef15.mp4"
global.thumb = "https://i.ibb.co/pjyr56L/image.jpg"
global.thumb2 = "https://i.ibb.co/pjyr56L/image.jpg"
global.mark = "https://i.ibb.co/pjyr56L/image.jpg"
global.themeemoji = '🌐'

//=== Introgasi 🗿
global.umurowner = "14" // Terserah🗿
global.kelasowner = "7F" // Terserah🗿
global.statusowner = "↑" // Terserah
global.lakiapacewek = "Laki" // Terserah
// Kalo mau gak diisi juga gak papa

//=== Payment 😋
global.qris = "085866034212"
global.pulsa = "085723701289"
global.dana = "085866034212"
global.gopay = "Gak ada"
global.rek = "MAU NGAPAIN BANG"

//=== Nokos Token 😱
global.apikey ='8c3a5b302815a138d88148fa0c5916c0595bba50' 

//=== Apikey Nya 🔥
global.lol = 'GataDios'
global.lol = 'SGWN'
global.rose = 'Rs-putangina'
global.xyro = 'CIYiVxDJ'
global.APIs = {
xyro: "https://api.betabotz.eu.org",
popcat : 'https://api.popcat.xyz'
}
// APIKeys
global.APIKeys = {
"https://api.betabotz.eu.org": "CIYiVxDJ"
}

//=== Gak Tau 🐦
global.pairingNumber = "6285723701289"
// Nomor whatsapp bot lu
global.prefix = ['-_-'] 
// Jangan diubah
global.tekspushcontact = "Izin Push" 
// Terserah
global.typemenu = "v6"
// Ini type menu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.typeallmenu = "v6"
// Ini type allmenu nya
// v1 - v2 - v3 - v4 - v5 - v6
global.game = true
// False (Nonaktifin)
global.groupOnly = false
// True (Mode grup)
global.privateOnly = false
// True (Mode grup)
global.antispam = true
// False (Nonaktifin)
global.anticall = true
// False (Nonaktifin)
global.autoreadsw = true
// False (Nonaktifin)
global.antiBot = true
// False (Nonaktifin)
global.pengingat = true
// False (Nonaktifin)
global.autoTyping = false
// False (Nonaktifin)
global.autoBio = true
// False (Nonaktifin)
global.autoRestart = false
// False (Nonaktifin)
// AutoRestart Cocok Tuk Panel Butut
global.mess = {
 done: 'Sukses!',
 wait: 'Sedang diproses',
 admin: 'Fitur Khusus Admin grup!',
 botNotAdmin: 'Saya bukan Admin grup',
 owner: 'Fitur Khusus Owner!',
 group: 'Fitur Khusus Group!',
}

// Setting Game
global.gamewaktu = 60 // Game waktu
global.bmin = 1000 // Balance minimal 
global.bmax = 5000 // Balance maksimal
global.limit = 30 // Limit user

// Database Game
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};

